package com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;



@Entity
@Table(name="Pacientes")
@SequenceGenerator(name="paciente", sequenceName = "SQ_PACIENTES", allocationSize = 1)
public class Pacientes  {

    @Id
    @Column(name="PacienteID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "paciente")
    private Integer id;
    
    @Column(name="Nome", nullable = false, length = 255)
    private String nome;
    
    @Temporal(TemporalType.DATE)
    @Column(name="DataNascimento", nullable = false)
    private Calendar dataNascimento;
    
    @Column(name="Endereco", length = 255)
    private String endereco;
    
    @Column(name="Telefone", length = 20)
    private String telefone;
    
    @Column(name="Email", length = 100)
    private String email;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="DataCadastro", nullable = false, updatable = false)
    private Calendar dataCadastro;
    
    public Pacientes() {}
    
    public Pacientes(String nome, Calendar dataNascimento, String endereco, String telefone, String email) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.endereco = endereco;
        this.telefone = telefone;
        this.email = email;
    }
    
    @PostPersist
    private void executar() {
        System.out.println("Persistência realizada com sucesso.");
    }

    // Getters e Setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Calendar getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Calendar dataNascimento) {
        this.dataNascimento = dataNascimento;
    }


    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Calendar getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Calendar dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

	
}
