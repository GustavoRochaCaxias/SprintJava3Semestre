package com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import com.fiap.entity.Pacientes;
public class PacientesDaoImpl extends GenericDaoImpl<Pacientes, Integer> implements PacienteDao{
	public PacientesDaoImpl(EntityManager em) {
			super(em);
		}

	@Override
	public List<Pacientes> list() {
		// TODO Auto-generated method stub
		return null;
	}
		
	}

