package com.fiap.exception;


public class IdNaoEncontradoException extends Exception {

	public IdNaoEncontradoException(String msg) {
		super(msg);
	}
}
