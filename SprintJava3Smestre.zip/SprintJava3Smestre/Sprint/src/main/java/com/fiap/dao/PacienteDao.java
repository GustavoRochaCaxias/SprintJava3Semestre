package com.fiap.dao;

import java.util.List;

import com.fiap.entity.Pacientes;

public interface PacienteDao extends GenericDao<Pacientes, Integer> {

	List<Pacientes> list();
    
}
