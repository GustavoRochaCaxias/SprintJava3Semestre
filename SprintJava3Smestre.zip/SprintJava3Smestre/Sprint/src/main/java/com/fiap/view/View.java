package com.fiap.view;


import javax.persistence.EntityManager;
import com.fiap.dao.PacienteDao;
import com.fiap.dao.PacientesDaoImpl;
import com.fiap.entity.Pacientes;
import com.fiap.exception.CommitException;
import com.fiap.exception.IdNaoEncontradoException;
import com.fiap.jpa.singleton.EntityManagerFactorySingleton;

import java.util.Calendar;

public class View {

    public static void main(String[] args) {
        // Obter o entity manager
        EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();

        // Instanciar o DAO do Paciente
        PacienteDao dao = new PacientesDaoImpl(em);

        // Criar um objeto Calendar para a data de nascimento
        Calendar dataNascimento = Calendar.getInstance();
        dataNascimento.set(1990, Calendar.JANUARY, 1);

        // Instanciar um Paciente (utilizando o construtor)
        Pacientes paciente = new Pacientes("João Silva", dataNascimento, "Rua Exemplo, 123", "11999999999", "joao.silva@email.com");

        // Cadastrar o paciente
        try {
            dao.salvar(paciente);
            dao.commit();
            System.out.println("Paciente cadastrado!");
        } catch (CommitException e) {
            System.err.println("Erro ao cadastrar paciente: " + e.getMessage());
        }

        // Pesquisar e atualizar um paciente
        try {
            // Buscar paciente pelo ID
            Pacientes busca = dao.buscar(1);
            System.out.println("Paciente encontrado: " + busca.getNome());

            // Atualizar telefone do paciente
            busca.setTelefone("11888888888");
            dao.salvar(busca);
            dao.commit();
            System.out.println("Paciente atualizado!");
        } catch (CommitException e) {
            System.err.println("Erro ao atualizar paciente: " + e.getMessage());
        } catch (IdNaoEncontradoException e) {
            System.err.println("Paciente não encontrado: " + e.getMessage());
        }

        // Remover um paciente (opcional)
        /*
        try {
            dao.remover(1);
            dao.commit();
            System.out.println("Paciente removido!");
        } catch (Exception e) {
            System.err.println("Erro ao remover paciente: " + e.getMessage());
        }
        */
    }
}

