package com.fiap.DbTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Testconexao {
	private static final String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:orcl";
    private static final String USER = "rm553310";
    private static final String PASSWORD = "300103";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void main(String[] args) {
        try {
            Connection connection = getConnection();
            if (connection != null && !connection.isClosed()) {
                System.out.println("Conexão com o banco de dados Oracle bem-sucedida!");
            } else {
                System.out.println("Falha ao conectar com o banco de dados.");
            }
            connection.close();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }
	
}
}
